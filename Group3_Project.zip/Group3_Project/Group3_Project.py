# =============================================================================
# Code By:
# Siyang Huang <sh5958@nyu.edu>
# Feifan Li <fl2221@nyu.edu>
# Chang Liu <cl5549@nyu.edu> 
# =============================================================================
import getdash
from stock import Stock, Stock_List
from graph import Graph
from getdash import GetDash
from strategy import Strategies

import numpy as np
import pandas as pd
from dash import Dash, html, dcc, dash_table
from dash.dependencies import Input, Output


#  %% Dash app
app = Dash()

#  %% Get Data of ticker_list
# tickers = Stock_List.get_all_stocks()
# global variables
# Part1
stock = None
# Part2
strategy = None
tbl = pd.DataFrame([['Null'] * 4, ['Null'] * 4], columns=['Annualized Return', 'Annualized std', 'Sharpe Ratio', 'MDD'],
                   index=['strategy', 'benchmark']).reset_index()


# Part1 functions todo


@app.callback(
    Output(component_id='Tickers', component_property='value'),
    Input(component_id='Tickers', component_property='value'),
    Input(component_id='Date_Range', component_property='start_date'),
    Input(component_id='Date_Range', component_property='end_date')
)
def generate_stock(name, start_date, end_date):
    global stock
    if not name:
        stock = None
        return None
    stock = Stock(name, start_date, end_date)
    if stock is None or len(stock.data) < 10:
        stock = None
    return name


@app.callback(
    Output(component_id='figure1', component_property='figure'),
    Input(component_id='Tickers', component_property='value'),
    prevent_initial_call=True
    )
def generate_price_fig(ticker):
    fig = Graph.get_empty_fig_timeseries_style1("Stock Price Plot", "Date Range", "Stock Close Price")
    global stock
    if not stock:
        return fig
    # Data Download Section
    if not len(stock.data):
        return fig
    ticker = stock.data
    price = ticker['Adj Close']
    time = ticker.index
    # Graph generation
    fig = Graph.add_line(fig=fig, x=time, y=price)
    return fig


@app.callback(
    Output(component_id='figure2', component_property='figure'),
    Input(component_id='Tickers', component_property='value'),
    prevent_initial_call=True)
def generate_return_fig(ticker):
    fig = Graph.get_empty_fig_timeseries_style1("Stock Return Plot", "Date Range", "Stock Daily Return")
    global stock
    if not stock:
        return fig
    # Data Download Section
    if not len(stock.data):
        return fig
    ticker = stock.data
    return_ = ticker['Return']
    time = ticker.index
    # Graph generation
    fig = Graph.add_line(fig=fig, x=time, y=return_)
    return fig


@app.callback(
    Output(component_id='figure3', component_property='figure'),
    Input(component_id='Tickers', component_property='value'),
    prevent_initial_call=True)
def generate_bar_fig(ticker):
    fig = Graph.get_empty_fig_bar_style1("Stock Return Bar Plot", "Price Range", "Stock Daily Return")
    global stock
    if not stock:
        return fig
    # Data Download Section
    if not len(stock.data):
        return fig

    price_min = stock.data['Adj Close'].min()
    price_max = stock.data['Adj Close'].max()
    interval = 5
    range_ = (price_max - price_min) / interval
    pctls = [round(i * range_ + price_min, 3) for i in range(interval)] + [price_max]
    stock.data['labels'] = pd.cut(stock.data['Adj Close'].to_list(), pctls)
    # Graph generation
    y_ = stock.data['Return'].groupby(stock.data['labels']).mean().to_list()
    fig = Graph.add_bar(fig=fig, x=pctls, y=y_)
    return fig


@app.callback(
    Output('Number of Traces', 'style'),
    Output('Number of Days', 'style'),
    Input(component_id='Tickers', component_property='value'),
    )
def select_parameter(ticker):
    show = {'font-size': '1em', 'width': '20em', "text-align": "center"}
    not_show = {'display': 'none'}
    global stock
    if stock is None:
        return not_show, not_show
    else:
        return show, show


@app.callback(
    Output(component_id='figure4', component_property='figure'),
    Input(component_id='Tickers', component_property='value'),
    Input('num_trace', 'value'),
    Input('num_day', 'value'),
    prevent_initial_call=True)
def generate_mc_price_fig(ticker, num_traces, num_days):
    fig = Graph.get_empty_fig_timeseries_style2("Stock Price Prediction (Monte Carlo)", "Date Range", "Stock Price Prediction")

    global stock
    if not stock or not num_traces or not num_days:
        return fig
    # Data Download Section
    if not len(stock.data):
        return fig
    stock.monte_carlo(num_traces, num_days)
    # ticker = t.data
    price_simulation = stock.monte_carlo_list

    for i in range(num_traces):
        fig = Graph.add_line(fig=fig, x=np.arange(len(price_simulation[i])), y=price_simulation[i])
    return fig


# Part2 functions todo


@app.callback(
    Output(component_id='Stocks', component_property='value'),
    Input(component_id='Stocks', component_property='value'),
    Input(component_id='Date_Range_for_Backtest', component_property='start_date'),
    Input(component_id='Date_Range_for_Backtest', component_property='end_date')
)
def generate_strategy(stock_name, start_date, end_date):
    global strategy
    if not stock_name:
        return None
    strategy = Strategies(stock_name, start_date, end_date)
    if not strategy.stock:
        return stock_name
    if len(strategy.stock.data) < 10:
        return stock_name
    strategy.get_benchmark_nav()
    return stock_name


@app.callback(
    Output('short-term', 'style'),
    Output('long-term', 'style'),
    Output('hmm', 'style'),
    Output('short', 'style'),
    Input(component_id='Which_Strategy', component_property='value'),
    )
def show_parameters(strategy_name):
    show = {'width': '15em', "text-align": "center"}
    not_show = {'display': 'none'}
    if strategy_name is None:
        return not_show, not_show, not_show, not_show
    elif strategy_name == 'Two-Period Simple Moving Average':
        return show, show, not_show, show
    elif strategy_name == 'RSI':
        return show, show, not_show, show
    elif strategy_name == 'Hidden Markov Model':
        return not_show, not_show, show, show


@app.callback(
    Output(component_id='figure_2_1', component_property='figure'),
    Output(component_id='figure_2_2', component_property='figure'),
    Output(component_id='tbl', component_property='data'),
    Input(component_id='Stocks', component_property='value'),
    Input(component_id='Which_Strategy', component_property='value'),
    Input('Date_Range_for_Backtest', 'start_date'),
    Input('Date_Range_for_Backtest', 'end_date'),
    Input('short_term_window', 'value'),
    Input('long_term_window', 'value'),
    Input('hmm_states', 'value'),
    Input('Go_short?', 'value'),
    prevent_initial_call=True
    )
def adjust_strategy_parameters(stock_name, which_strat, start, end, short, long, hmm_states, if_short):
    fig = Graph.get_empty_fig_timeseries_style1("Net Asset Value Curve", "Date Range", "Net Asset Value Comparison")
    fig2 = Graph.get_empty_fig_bar_style1("Monthly Return Bar", "Date Range", "Monthly Return Comparison")
    df = pd.DataFrame([[0] * 4, [0] * 4], columns=['Annualized Return', 'Annualized std', 'Sharpe Ratio', 'MDD'],
                      index=['strategy', 'benchmark']).reset_index().to_dict('Records')
    if not stock_name or not which_strat or not short or not long or not hmm_states or not if_short:
        return fig, fig2, df

    global strategy
    if not strategy or not strategy.stock:
        return fig, fig2, df
    if not len(strategy.stock.data):
        return fig, fig2, df
    short_allowed = True if if_short == 'Y' else False
    if which_strat == 'Two-Period Simple Moving Average':
        strategy.double_ma(short, long, short_allowed)
        key = (stock_name, "MA", start, end, short, long, short_allowed)
    elif which_strat == 'Hidden Markov Model':
        strategy.hmm(hmm_states, short_allowed)
        key = (stock_name, "HMM", start, end, hmm_states, short_allowed)
    elif which_strat == 'RSI':
        strategy.rsi(short, long, short_allowed)
        key = (stock_name, "RSI", start, end, short, long, short_allowed)
    nav = strategy.show_nav_comparison(key)
    ret = strategy.show_monthly_comparison(key)
    df = strategy.show_performance_table(key).to_dict("records")
    if nav is None or not len(nav) or ret is None or not len(ret):
        return fig, fig2, df

    time = nav.index
    y1 = nav['long_hold']
    y2 = nav[key[1]]
    fig = Graph.add_line(fig, time, y1, 'benchmark')
    fig = Graph.add_line(fig, time, y2, 'strategy')

    time = ret.index
    y1 = ret['long_hold']
    y2 = ret[key[1]]
    fig2 = Graph.add_bar(fig2, time, y1, 'benchmark')
    fig2 = Graph.add_bar(fig2, time, y2, 'strategy')
    return fig, fig2, df


app.layout = html.Div(
    [
        # Part1 todo
        html.Center(html.H1('Market Timing Equity Trading Strategy Platform', style={'color': 'white', 'font-weight': 'bold',
                                                                                     'font-size': '2em'})),
        html.Hr(style={'border': '3px solid white'}),
        html.Br(),
        html.Div('''Part 1: Display graphs of stock price, stock return, return distribution, 
        as well as the Monte-Carlo simulation on stock price.''',
                 style={
                    'width': '66%',
                    'font-size': '1.5em',
                    'text-align': 'center',
                    'margin-left': 'auto',
                    'margin-right': 'auto',
                    'color': 'powderblue'
                 }
                 ),


        # inputs
        html.Div([
            # set ticker and date
            html.Div(GetDash.get_date_range('Date Range', start_date='2016-01-01', end_date='2022-12-31'),
                     style={'font-size': '1em', 'margin-right': '1em', 'width': '20em'}),
            html.Div(GetDash.get_dropdown('Tickers', Stock_List.get_tickers_label_value(),
                                          placeholder='Select a stock ticker...', multi=False),
                     style={'font-size': '1em', 'margin-right': '1em', 'width': '15em'}),

            # set Monte-Carlo simulation parameters
            html.Div(id='Number of Traces',
                     children=GetDash.get_parameter(name='Number of Traces', id_='num_trace', value=50, min_=10,
                                                    max_=200, step=10),
                     style={'display': 'none'}),
            html.Div(id='Number of Days',
                     children=GetDash.get_parameter(name='Number of Days', id_='num_day', value=30, min_=10,
                                                    max_=100, step=5),
                     style={'display': 'none'}),
            ],
            style={
                'display': 'flex',
                'flex-direction': 'row',
                'padding': '2em'
            }
        ),


        # plots
        html.Div([
            # price fig
            dcc.Loading(dcc.Graph(id='figure1'), type="cube",),
            # return fig
            dcc.Loading(dcc.Graph(id='figure2'),  type="cube",),
        ], style={'display': 'flex', 'flex-direction': 'row', 'padding': '1em'}),

        html.Div([
            # return bar fig
            dcc.Loading(dcc.Graph(id='figure3'), type="cube",),
            # price Monte-Carlo simulation fig
            dcc.Loading(dcc.Graph(id='figure4'), type="cube",),
        ], style={'display': 'flex', 'flex-direction': 'row', 'padding': '1em'}),
        html.Br(),
        html.Br(),


        # Part2 todo
        html.Hr(style={'border': '3px solid white'}),
        html.Br(),
        html.Div('''Part 2: Display the backtest results of chosen market timing strategy for chosen stock.''',
                 style={
                    'width': '80%',
                    'font-size': '1.5em',
                    'text-align': 'center',
                    'margin-left': 'auto',
                    'margin-right': 'auto',
                    'color': 'powderblue'
                 }
                 ),


        # Inputs
        html.Div([
            html.Div(GetDash.get_date_range('Date Range for Backtest', start_date='2016-01-01', end_date='2022-12-31'),
                     style={'font-size': '1em', 'margin-right': '2em', 'width': '20em'}),
            html.Div(GetDash.get_dropdown('Stocks', Stock_List.get_tickers_label_value(),
                                          placeholder='Select a stock ticker...', multi=False),
                     style={'font-size': '1em', 'margin-right': '4em', 'width': '15em'}),
            html.Div(GetDash.get_dropdown('Which Strategy',
                                          [{'label': 'Two-Period Simple Moving Average (SMA)',
                                            'value': 'Two-Period Simple Moving Average'},
                                           {'label': 'Hidden Markov Model (HMM)',
                                            'value': 'Hidden Markov Model'},
                                           {'label': 'Relative Strength Index (RSI)',
                                            'value': 'RSI'},
                                           ],
                                          placeholder='Select a strategy...', multi=False),
                     style={'font-size': '1em', 'margin-right': '2em', 'width': '30em'}),
            ],
            style={
                'display': 'flex',
                'flex-direction': 'row',
                'padding': '2em'
            }
        ),

        # strategy parameters
        html.Div([
            html.Div(id='short-term',
                     children=GetDash.get_parameter(name='Short Term', id_='short_term_window', value=10,
                                                    min_=1, max_=60, step=1),
                     style={'display': 'none'}),
            html.Div(id='long-term',
                     children=GetDash.get_parameter(name='Long Term', id_='long_term_window', value=30,
                                                    min_=1, max_=120, step=1),
                     style={'display': 'none'}),
            html.Div(id='hmm',
                     children=GetDash.get_parameter(name='Number of States', id_='hmm_states', value=3,
                                                    min_=2, max_=3, step=1),
                     style={'display': 'none'}),
            html.Div(id='short',
                     children=GetDash.get_dropdown(name='Go short?', options=[{'label': 'Yes', 'value': 'Y'},
                                                                              {'label': 'No', 'value': 'N'}],
                                                   placeholder="Choose if you can go short...", multi=False),
                     style={'display': 'none'}),
            ],
            style={
                'display': 'flex',
                'flex-direction': 'row',
            }
        ),


        # plots
        html.Div([
            # price fig
            dcc.Loading(dcc.Graph(id='figure_2_1'), type="cube", ),
            # return fig
            dcc.Loading(dcc.Graph(id='figure_2_2'), type="cube", ),
        ], style={'display': 'flex', 'flex-direction': 'row', 'padding': '1em'}),
        html.Br(),
        html.Br(),


        # table
        html.Div('''Strategy Performance DataTable''',
                 style={
                    'width': '80%',
                    'font-size': '1.5em',
                    'text-align': 'center',
                    'margin-left': 'auto',
                    'margin-right': 'auto',
                    'color': 'white'
                 }
                 ),
        dash_table.DataTable(data=tbl.to_dict('records'), columns=[{"name": i, "id": i} for i in tbl.columns],
                             id='tbl'),
        html.Br(),



    ],
    style={
        'margin': '3em',
        'border-radius': '3em',
        'border': 'solid white 6px',
        'padding': '3em',
        'background': 'royalblue'
    }
)


if __name__ == "__main__":
    print('About to start...')

    app.run_server(
        debug=True,
        port=8070)
