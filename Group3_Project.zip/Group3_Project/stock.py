import pandas as pd
import yfinance as yf
import numpy as np


class Stock_List:

    stock_list = pd.read_csv("resources/small_tickers.csv", usecols=["Symbol"])

    @classmethod
    def get_all_stocks(cls):
        return cls.stock_list

    @classmethod
    def get_tickers_label_value(cls):
        return [{'label': c, 'value': c} for c in cls.stock_list['Symbol'].drop_duplicates()]


class Stock:

    def __init__(self, name, start, end):
        self.name = name
        self.data = pd.DataFrame(yf.download(self.name, start=start, end=end))
        # self.data = self.data.reset_index()
        # self.data['Date'] = pd.to_datetime(self.data['Date'], errors='coerce')
        # self.data['Date'] = self.data["Date"].dt.date
        # self.data.set_index('Date', inplace=True)
        self.start = self.data.index[0] if len(self.data) else None
        self.end = self.data.index[-1] if len(self.data) else None
        self.monte_carlo_list = np.array([])
        if len(self.data) > 1:
            self.calculate_return()

    def calculate_return(self, shift=1):
        ret = self.data['Adj Close'].pct_change(shift)
        if shift == 1:
            self.data['Return'] = ret
            self.data.dropna(inplace=True)
        return ret

    def monte_carlo(self, num_traces=100, num_days=60):
        close = self.data["Adj Close"]
        look_back = 60 if len(close) > 60 else len(close)
        mean = (close[-1] / close[-look_back]) ** (1 / look_back) - 1
        # print(mean)
        sigma = close[-look_back:].pct_change().std()
        # print(sigma)
        price_simulation = np.zeros((num_traces, 1))
        price_simulation += close[-1]
        for i in range(1, num_days):
            epsilon = np.random.randn(num_traces, 1)
            cur_date_price = (price_simulation[:, -1] * (mean + 1)).reshape(num_traces, 1) +\
                price_simulation[:, -1].reshape(num_traces, 1) * sigma * epsilon
            price_simulation = np.concatenate((price_simulation, cur_date_price), axis=1)
        self.monte_carlo_list = price_simulation
        return price_simulation


if __name__ == "__main__":
    stock = Stock("AACIW", "1980-01-01", "2022-12-31")
    print(len(stock.data))
    # stock.calculate_return()
    # stock.monte_carlo(100, 60)
    # print(stock.monte_carlo_list[0].shape)
