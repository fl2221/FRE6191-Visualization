import pandas as pd
import yfinance as yf

tickers = pd.read_csv('resources/tickers.csv', usecols=["Symbol"])

small_tickers = []

for i in range(len(tickers)):
    if '^' in tickers.iloc[i, 0]:
        continue
    stock = yf.download(tickers.iloc[i, 0], '2021-01-01', '2022-12-31')
    if stock is None or len(stock) < 252:
        continue
    small_tickers.append(tickers.iloc[i, 0])
