from dash import Dash, html, dcc
from datetime import date


class GetDash:

    @staticmethod
    def get_title(name):
        title = [
            html.Div(name,
                     style={'width': '80%',
                            'font-size': '2em',
                            'text-align': 'center',
                            'margin-left': 'auto',
                            'margin-right': 'auto',
                            'color': 'white'}
                     ),
        ]
        return title

    @staticmethod
    def get_dropdown(name, options, placeholder, multi=False, disabled=False):
        dropdown = [
            html.Label(name + ':', style={'color': 'white', 'font-size': '1.5em'}),
            dcc.Dropdown(id=name.replace(' ', '_'), options=options, placeholder=placeholder, multi=multi,
                         disabled=disabled),
        ]
        return dropdown

    @staticmethod
    def get_parameter(name, id_, value, min_=10.0, max_=200.0, step=1.0):
        content = [
            html.Label(name + ':', style={'color': 'white', 'font-size': '1.5em'}),
            dcc.Input(id=id_.replace(' ', '_'), value=value, type="number", min=min_, max=max_, step=step,
                      style={'width': '3em'}),
        ]
        return content

    @staticmethod
    def get_date_range(name, start_date='2000-01-01', end_date='2022-12-31'):
        date_range = [
            html.Label(name + ':', style={'color': 'white', 'font-size': '1.5em'}),
            dcc.DatePickerRange(id=name.replace(' ', '_'),
                                start_date=date(*[int(x) for x in start_date.split('-')]),
                                end_date=date(*[int(x) for x in end_date.split('-')]),
                                min_date_allowed=date(1900, 1, 1),
                                max_date_allowed=date(2022, 12, 31),
                                initial_visible_month=date(2000, 1, 1),
                                ),
        ]
        return date_range