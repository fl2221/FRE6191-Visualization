import plotly.graph_objects as go
from dash import dash_table
import pandas as pd


class Graph:

    @staticmethod
    def get_empty_fig_timeseries_style1(title, x_title, y_title):
        fig = go.Figure()
        # Graph formatting
        fig.update_layout(
            title={'text': title, 'y': 0.95, 'x': 0.5, 'font': {'size': 20}},
            xaxis={'title': x_title, 'title_font_color': "Navy", 'title_font_size': 15},
            yaxis={'title': y_title, 'title_font_color': "Navy", 'title_font_size': 15},
            paper_bgcolor="snow",
            plot_bgcolor="whitesmoke",
            height=500,
            width=600
        )

        # Add range slider
        fig.update_layout(
            xaxis=dict(
                rangeselector=dict(
                    buttons=list([
                        dict(count=1,
                             label="1d",
                             step="day",
                             stepmode="backward"
                             ),
                        dict(count=1,
                             label="1m",
                             step="month",
                             stepmode="backward"
                             ),
                        dict(count=6,
                             label="6m",
                             step="month",
                             stepmode="backward"
                             ),
                        dict(count=1,
                             label="YTD",
                             step="year",
                             stepmode="todate"
                             ),
                        dict(count=1,
                             label="1y",
                             step="year",
                             stepmode="backward"
                             ),
                        dict(step="all")
                    ])
                ),
                rangeslider=dict(
                    visible=True
                ),
                type="date",
            )
        )
        return fig

    @staticmethod
    def get_empty_fig_timeseries_style2(title, x_title, y_title):
        fig = go.Figure()
        # Graph formatting
        fig.update_layout(
            title={'text': title, 'y': 0.95, 'x': 0.5, 'font': {'size': 20}},
            xaxis={'title': x_title, 'title_font_color': "Navy", 'title_font_size': 15},
            yaxis={'title': y_title, 'title_font_color': "Navy", 'title_font_size': 15},
            paper_bgcolor="snow",
            plot_bgcolor="whitesmoke",
            height=500,
            width=600
        )
        return fig

    @staticmethod
    def get_empty_fig_bar_style1(title, x_title, y_title):
        fig = go.Figure()
        # Graph formatting
        fig.update_layout(
            title={'text': title, 'y': 0.95, 'x': 0.5, 'font': {'size': 20}},
            xaxis={'title': x_title, 'title_font_color': "Navy", 'title_font_size': 15},
            yaxis={'title': y_title, 'title_font_color': "Navy", 'title_font_size': 15},
            paper_bgcolor="snow",
            plot_bgcolor="whitesmoke",
            height=500,
            width=600
        )
        return fig

    @staticmethod
    def add_scatter(fig, x, y, *args):
        if len(args):
            fig.add_trace(go.Scatter(y=list(y), x=list(x), name=args[0]))
        else:
            fig.add_trace(go.Scatter(y=list(y), x=list(x)))
        return fig

    @staticmethod
    def add_line(fig, x, y, *args):
        if len(args):
            fig.add_trace(go.Line(y=list(y), x=list(x), name=args[0]))
        else:
            fig.add_trace(go.Line(y=list(y), x=list(x)))
        return fig

    @staticmethod
    def add_bar(fig, x, y, *args):
        if len(args):
            fig.add_trace(go.Bar(y=list(y), x=list(x), name=args[0]))
        else:
            fig.add_trace(go.Bar(y=list(y), x=list(x)))
        return fig


if __name__ == "__main__":
    Graph.get_empty_fig_timeseries_style1()
