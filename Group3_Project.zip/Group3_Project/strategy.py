from stock import Stock, Stock_List

import numpy as np
import pandas as pd
import hmmlearn.hmm as hmm


class Strategies:

    strategy_dict = dict()

    def __init__(self, stock_name: str, start, end):
        self.stock_name = stock_name
        self.stock = Stock(stock_name, '1980-01-01', '2022-12-31')
        self.start = start
        self.end = end
        self.data = None
        self.benchmark_nav = None

    def get_benchmark_nav(self):
        if len(self.stock.data) < 100:
            self.benchmark_nav = None
            return
        data = self.stock.data.loc[self.start: self.end, ['Return']]
        self.benchmark_nav = np.cumprod(1 + data['Return']).to_frame()

    def double_ma(self, short_term=10, long_term=20, if_short=False):
        if (self.stock_name, "MA", self.start, self.end, short_term, long_term, if_short) \
                in self.__class__.strategy_dict:
            return
        if len(self.stock.data) < 100:
            self.__class__.strategy_dict[(self.stock_name, "MA", self.start, self.end, short_term,
                                          long_term, if_short)] = None
            return
        data = self.stock.data.copy()
        data['MA_short'] = data['Adj Close'].rolling(short_term).mean()
        data['MA_long'] = data['Adj Close'].rolling(long_term).mean()
        data.dropna(inplace=True)
        if if_short:
            data['signal'] = (data['MA_short'] > data['MA_long']).astype(int) * 2 - 1
        else:
            data['signal'] = (data['MA_short'] > data['MA_long']).astype(int)
        data['signal'] = data['signal'].shift(1)
        data.dropna(inplace=True)
        data = data.loc[self.start: self.end]
        if not len(data):
            self.__class__.strategy_dict[(self.stock_name, "MA", self.start, self.end,
                                          short_term, long_term, if_short)] = None
            return
        self.__class__.strategy_dict[(self.stock_name, "MA", self.start, self.end,
                                       short_term, long_term, if_short)] = \
            np.cumprod(1 + data['Return'] * data['signal']).to_frame()

    def rsi(self, short=6, long=14, if_short=False):
        if (self.stock_name, "RSI", self.start, self.end, short, long, if_short) in self.__class__.strategy_dict:
            return
        if len(self.stock.data) < 100:
            self.__class__.strategy_dict[(self.stock_name, "RSI", self.start, self.end, short, long, if_short)] = None
            return
        data = self.stock.data.copy()
        data['rsi_short'] = 100 * data['Adj Close'].diff().apply(lambda x: max(x, 0)).rolling(short).sum() / \
            data['Adj Close'].diff().apply(lambda x: abs(x)).rolling(short).sum()
        data['rsi_long'] = 100 * data['Adj Close'].diff().apply(lambda x: max(x, 0)).rolling(long).sum() / \
            data['Adj Close'].diff().apply(lambda x: abs(x)).rolling(long).sum()
        if if_short:
            data['signal'] = (data['rsi_short'] > data['rsi_long']).astype(int) * 2 - 1
        else:
            data['signal'] = (data['rsi_short'] > data['rsi_long']).astype(int)
        data['signal'] = data['signal'].shift(1)
        data.dropna(inplace=True)
        data = data.loc[self.start: self.end]
        if not len(data):
            self.__class__.strategy_dict[(self.stock_name, "RSI", self.start, self.end, short, long, if_short)] = None
            return
        self.__class__.strategy_dict[(self.stock_name, "RSI", self.start, self.end, short, long, if_short)] = \
            np.cumprod(1 + data['Return'] * data['signal']).to_frame()

    def hmm(self, num_states=2, if_short=False):
        if (self.stock_name, "HMM", self.start, self.end, num_states, if_short) in self.__class__.strategy_dict:
            return
        if len(self.stock.data) < 100:
            self.__class__.strategy_dict[(self.stock_name, "HMM", self.start, self.end, num_states, if_short)] = None
            return
        data = self.stock.data.copy()
        x_train = data.loc[data.index < self.start, ["Return"]]
        if len(x_train) < 100:
            self.__class__.strategy_dict[(self.stock_name, "HMM", self.start, self.end, num_states, if_short)] = None
            return
        if len(x_train) > 1000:
            x_train = x_train.iloc[-1000:, :]
        x_test = data.loc[(data.index >= self.start) & (data.index <= self.end), ["Return"]]

        model = hmm.GaussianHMM(n_components=num_states, covariance_type='diag', n_iter=1000).fit(x_train)

        params = pd.DataFrame(columns=('State', 'Return Mean', 'Return Variance'))
        for i in range(model.n_components):
            params.loc[i] = [format(i), model.means_[i][0], np.diag(model.covars_[i])[0]]
        params.sort_values(by=['Return Mean'], inplace=True, ascending=False)
        params.reset_index(inplace=True, drop=True)
        params['State'] = params['State'].astype(int)
        params['real_State'] = 1 - params.index.values

        d = dict(zip(params['State'], params['real_State']))

        pred_hidden_states_test = model.decode(x_test, algorithm='viterbi')[1]
        x_test['pred_states'] = pd.Series(pred_hidden_states_test.reshape(-1), index=x_test.index).astype(int)
        x_test['pred_states'] = x_test['pred_states'].apply(lambda x: d[x])
        short_position = 0 if num_states == 2 else -1
        if if_short:
            data['signal'] = (x_test['pred_states'] != short_position).astype(int) * 2 - 1
        else:
            data['signal'] = (x_test['pred_states'] != short_position).astype(int)
        data.dropna(inplace=True)
        data = data.loc[self.start: self.end]
        print(data)

        if not len(data):
            self.__class__.strategy_dict[(self.stock_name, "HMM", self.start, self.end, num_states, if_short)] = None
            return
        self.__class__.strategy_dict[(self.stock_name, "HMM", self.start, self.end, num_states, if_short)] = \
            np.cumprod(1 + data['Return'] * data['signal']).to_frame()

    def show_nav_comparison(self, key):
        benchmark = self.benchmark_nav
        ret = self.__class__.strategy_dict[key]
        if ret is None:
            return None
        ret = benchmark.merge(ret, left_index=True, right_index=True)
        ret.columns = ['long_hold', key[1]]
        if len(ret) < 30:
            return None
        return ret

    def show_monthly_comparison(self, key):
        benchmark = self.benchmark_nav
        ret = self.__class__.strategy_dict[key]
        if ret is None:
            return None
        res = pd.DataFrame([], columns=['long_hold', key[1]])
        ret = benchmark.merge(ret, left_index=True, right_index=True)
        ret.columns = ['long_hold', key[1]]
        if len(ret) < 30:
            return None
        for month, rates in ret.groupby(ret.index.astype(str).str[:7]):
            res.loc[month] = (rates.iloc[-1] / rates.iloc[0] - 1).T
        return res

    def show_performance_table(self, key):
        res = pd.DataFrame([], columns=['Annualized Return', 'Annualized std', 'Sharpe Ratio', 'MDD'],
                           index=['strategy', 'benchmark'])
        benchmark = self.benchmark_nav
        strat = self.__class__.strategy_dict[key]
        if strat is None or len(strat) < 30 or benchmark is None or len(benchmark) < 30:
            return res

        benchmark_ret = (benchmark.iloc[-1, 0] / benchmark.iloc[0, 0]) ** (252 / (len(benchmark) - 1)) - 1
        strat_ret = (strat.iloc[-1, 0] / strat.iloc[0, 0]) ** (252 / (len(strat) - 1)) - 1

        benchmark_std = benchmark.pct_change().std()[0] * np.sqrt(252)
        strat_std = strat.pct_change().std()[0] * np.sqrt(252)

        benchmark_sharpe = benchmark_ret / benchmark_std
        strat_sharpe = strat_ret / strat_std

        benchmark_max = benchmark.copy()
        for i in range(1, len(benchmark_max)):
            benchmark_max.iloc[i, 0] = max(benchmark_max.iloc[i - 1, 0], benchmark.iloc[i, 0])
        benchmark_MDD = ((benchmark - benchmark_max) / benchmark_max).min()[0]

        strat_max = strat.copy()
        for i in range(1, len(strat_max)):
            strat_max.iloc[i, 0] = max(strat_max.iloc[i - 1, 0], strat.iloc[i, 0])
        strat_MDD = ((strat - strat_max) / strat_max).min()[0]

        res.loc['strategy'] = [strat_ret, strat_std, strat_sharpe, strat_MDD]
        res.loc['benchmark'] = [benchmark_ret, benchmark_std, benchmark_sharpe, benchmark_MDD]
        res.reset_index(inplace=True)
        return res


if __name__ == "__main__":
    strat = Strategies("AAPL", '2019-01-01', '2022-01-01')
    strat.get_benchmark_nav()
    strat.rsi(20, 30, False)
